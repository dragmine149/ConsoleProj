using UnityEngine;

public class TestChangeScript : MonoBehaviour
{
    public static int A = 0;
    public bool B = false;
    public string C = "c";
}
