using UnityEngine;
using UnityEngine.UI;
using UnityEditor;
using System;
using System.Reflection;
using System.Linq;
using System.IO;
using System.Collections.Generic;

public class CommandsMain : MonoBehaviour
{
    public InputField commandInput;

    // get the command and fields
    public void CommandSubmit()
    {
        string calledCommand = commandInput.text;
        commandInput.text = ""; // reset for next use

        ProcessCommand(calledCommand);
    }

    // Get commands from the folders.
    private List<string> Commands => new List<string>(AssetDatabase.FindAssets("", new[] { "Assets/Console/Commands/BuiltIn", "Assets/Console/Commands/Custom" }));

    private void ProcessCommand(string commandInput)
    {
        // split the command up to the smaller parts.
        string[] commandBreak = commandInput.Split(" ".ToCharArray());
        string commandCalled = commandBreak[0];
        string[] paramaters = new string[] { commandInput.Replace(commandCalled + " ", "") };


        bool found = false;
        // tries and finds command in the list of commands
        foreach (string command in Commands)
        {
            string commandName = AssetDatabase.GUIDToAssetPath(command);
            commandName = Path.GetFileNameWithoutExtension(commandName);
            if (commandName.ToLower() == commandCalled.ToLower())
            {
                // runs command
                Type t = Type.GetType(commandName);
                MethodInfo info = t.GetMethod("Activate");
                info.Invoke(null, paramaters);
                found = true;
            }
        }

        if (!found)
        {
            console.LogMsg.LogError($"{commandCalled} is not a valid command!");
        }
        else
        {
            FindObjectOfType<ChangeVisible>().EnterCommand(); // hides the command section after use
        }
    }

    public void GetCommands()
    {
        // To list all commands in doing the ListCommand function. (import script)
        string commands = "Commands:\n";
        foreach (string command in Commands)
        {
            string ncommand = AssetDatabase.GUIDToAssetPath(command);
            ncommand = Path.GetFileNameWithoutExtension(ncommand);
            commands += $"{ncommand},\n";
        }
        Debug.Log(commands);
    }
}
