using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Test1 : MonoBehaviour
{
    // Update is called once per frame
    void Update()
    {
        Debug.Log(TestChangeScript.A);
    }
}
